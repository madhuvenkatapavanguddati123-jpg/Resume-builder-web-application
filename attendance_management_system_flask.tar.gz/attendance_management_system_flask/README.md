# Attendance Management System

A complete Flask project prototype for an Attendance Management System with multiple pages, responsive UI, and PostgreSQL schema.

## Modules
- Dashboard
- Attendance Management
- Grades Management
- Student Database
- Add Student
- Edit Student
- Student Profile
- Reports
- Announcements
- Settings
- PostgreSQL Schema

## Run
```bash
pip install -r requirements.txt
python app.py
```

## PostgreSQL
Use `schema.sql` to create database tables. The current demo uses in-memory sample data to make the project run instantly.
