from flask import Flask, render_template, request, redirect, url_for, flash
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'attendance-secret-key'

DASHBOARD = {
    'total_students': 1248,
    'today_attendance': '92.4%',
    'low_attendance_alerts': 18,
    'average_grade': '81.6%'
}

STUDENTS = [
    {
        'id': 1,
        'roll_no': '23CSE001',
        'name': 'Aryan Kumar',
        'department': 'CSE',
        'year': '3rd Year',
        'email': 'aryan@college.edu',
        'phone': '9876500011',
        'attendance': 91,
        'grade': 'A'
    },
    {
        'id': 2,
        'roll_no': '23CSE014',
        'name': 'Sneha Reddy',
        'department': 'CSE',
        'year': '3rd Year',
        'email': 'sneha@college.edu',
        'phone': '9876500012',
        'attendance': 94,
        'grade': 'A+'
    },
    {
        'id': 3,
        'roll_no': '23CSE023',
        'name': 'Rahul Das',
        'department': 'CSE',
        'year': '3rd Year',
        'email': 'rahul@college.edu',
        'phone': '9876500013',
        'attendance': 76,
        'grade': 'B+'
    },
    {
        'id': 4,
        'roll_no': '23CSE031',
        'name': 'Nisha Patel',
        'department': 'CSE',
        'year': '3rd Year',
        'email': 'nisha@college.edu',
        'phone': '9876500014',
        'attendance': 96,
        'grade': 'A+'
    }
]

ATTENDANCE_RECORDS = [
    {'roll_no': '23CSE001', 'name': 'Aryan Kumar', 'department': 'CSE', 'status': 'Present', 'time': '09:02 AM', 'faculty': 'Ms. Priya'},
    {'roll_no': '23CSE014', 'name': 'Sneha Reddy', 'department': 'CSE', 'status': 'Late', 'time': '09:18 AM', 'faculty': 'Ms. Priya'},
    {'roll_no': '23CSE023', 'name': 'Rahul Das', 'department': 'CSE', 'status': 'Absent', 'time': '-', 'faculty': 'Ms. Priya'},
    {'roll_no': '23CSE031', 'name': 'Nisha Patel', 'department': 'CSE', 'status': 'Present', 'time': '08:59 AM', 'faculty': 'Ms. Priya'}
]

GRADES = [
    {'name': 'Aryan Kumar', 'internal': '24/30', 'assignment': '18/20', 'lab': '45/50', 'total': '87/100', 'grade': 'A'},
    {'name': 'Sneha Reddy', 'internal': '26/30', 'assignment': '19/20', 'lab': '47/50', 'total': '92/100', 'grade': 'A+'},
    {'name': 'Rahul Das', 'internal': '20/30', 'assignment': '16/20', 'lab': '39/50', 'total': '75/100', 'grade': 'B+'},
    {'name': 'Nisha Patel', 'internal': '28/30', 'assignment': '18/20', 'lab': '46/50', 'total': '92/100', 'grade': 'A+'}
]

ANNOUNCEMENTS = [
    {'title': 'Internal Exams Start Monday', 'message': 'All students must check the exam timetable and be prepared with hall tickets.'},
    {'title': 'Attendance Review', 'message': 'Students below 75% attendance should meet the department mentor this week.'}
]


def get_student(student_id):
    return next((s for s in STUDENTS if s['id'] == student_id), None)


@app.route('/')
def home():
    return render_template('home.html', dashboard=DASHBOARD)


@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html', dashboard=DASHBOARD, students=STUDENTS, attendance=ATTENDANCE_RECORDS, grades=GRADES)


@app.route('/attendance')
def attendance():
    return render_template('attendance.html', attendance=ATTENDANCE_RECORDS, updated_at=datetime.now().strftime('%d %b %Y, %I:%M %p'))


@app.route('/grades')
def grades():
    return render_template('grades.html', grades=GRADES)


@app.route('/students')
def students():
    return render_template('students.html', students=STUDENTS)


@app.route('/students/add', methods=['GET', 'POST'])
def add_student():
    if request.method == 'POST':
        new_id = max([s['id'] for s in STUDENTS], default=0) + 1
        student = {
            'id': new_id,
            'roll_no': request.form.get('roll_no', ''),
            'name': request.form.get('name', ''),
            'department': request.form.get('department', ''),
            'year': request.form.get('year', ''),
            'email': request.form.get('email', ''),
            'phone': request.form.get('phone', ''),
            'attendance': int(request.form.get('attendance', 0) or 0),
            'grade': request.form.get('grade', '')
        }
        STUDENTS.append(student)
        flash('Student added successfully.')
        return redirect(url_for('students'))
    return render_template('add_student.html')


@app.route('/students/<int:student_id>/edit', methods=['GET', 'POST'])
def edit_student(student_id):
    student = get_student(student_id)
    if not student:
        flash('Student not found.')
        return redirect(url_for('students'))
    if request.method == 'POST':
        student['roll_no'] = request.form.get('roll_no', student['roll_no'])
        student['name'] = request.form.get('name', student['name'])
        student['department'] = request.form.get('department', student['department'])
        student['year'] = request.form.get('year', student['year'])
        student['email'] = request.form.get('email', student['email'])
        student['phone'] = request.form.get('phone', student['phone'])
        student['attendance'] = int(request.form.get('attendance', student['attendance']) or student['attendance'])
        student['grade'] = request.form.get('grade', student['grade'])
        flash('Student updated successfully.')
        return redirect(url_for('student_profile', student_id=student_id))
    return render_template('edit_student.html', student=student)


@app.route('/students/<int:student_id>')
def student_profile(student_id):
    student = get_student(student_id)
    if not student:
        flash('Student not found.')
        return redirect(url_for('students'))
    return render_template('student_profile.html', student=student)


@app.route('/reports')
def reports():
    return render_template('reports.html')


@app.route('/announcements', methods=['GET', 'POST'])
def announcements():
    if request.method == 'POST':
        title = request.form.get('title', '')
        message = request.form.get('message', '')
        if title and message:
            ANNOUNCEMENTS.insert(0, {'title': title, 'message': message})
            flash('Announcement posted successfully.')
        return redirect(url_for('announcements'))
    return render_template('announcements.html', announcements=ANNOUNCEMENTS)


@app.route('/settings')
def settings():
    return render_template('settings.html')


@app.route('/postgresql-schema')
def postgresql_schema():
    return render_template('postgresql_schema.html')


if __name__ == '__main__':
    app.run(debug=True)
